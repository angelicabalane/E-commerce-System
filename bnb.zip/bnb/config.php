<?php

$conn = mysqli_connect('localhost','root','','bake_db') or die('connection failed');
 
?> 