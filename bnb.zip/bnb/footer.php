<footer>
	<p>Beauty and the Bread</p>
	<div class="social">
      <a href="https://www.facebook.com/" class="fab fa-facebook-f"></a>
      <a href="https://www.instagram.com/" class="fab fa-instagram"></a>
      <a href="https://twitter.com/" class="fab fa-twitter"></a>
	</div>
	<p class="end"><span>Copyright By Beauty and the Bread. All Rights Reserved.</span></p>
</footer>